

function Addto_list(){
    list = document.getElementById("Materials_list")
    val = document.getElementById("n1").value
    newli = document.createElement("p");
    newli.setAttribute('id',val)
    newli.appendChild(document.createTextNode(val))
}

